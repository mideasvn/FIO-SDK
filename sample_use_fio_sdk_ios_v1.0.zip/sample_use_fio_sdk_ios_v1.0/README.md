FIO-SDK

FIO service is Chat/Call/Social Network SDK into your Mobile Apps. FIO powers real time messaging across & peer-to-peer call any device, any platform & anywhere in the world. Integrate our simple SDK to engage your users with image, file, location sharing and audio conversations & voice call peer-to-peer.

Source code and document about FIO SDK service. The product created by MIDEAS Co., ltd Contact: wwww.mideasvn.com - support@mideasvn.com - 0977.705.134
