//
//  main.m
//  iMC_Example
//
//  Created by TranQuangSon on 7/26/16.
//  Copyright © 2016 mideas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
