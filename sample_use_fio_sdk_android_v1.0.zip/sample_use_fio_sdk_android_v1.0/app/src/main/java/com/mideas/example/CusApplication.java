package com.mideas.example;

import com.mideas.fio.core.FIOApplication;

/**
 * Mo ta muc dich cua lop (interface)
 *
 * @author: DungHv10
 * @version: 1.0
 */
public class CusApplication extends FIOApplication {
}
