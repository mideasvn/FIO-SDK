package com.mideas.example;

/**
 * Mo ta muc dich cua lop (interface)
 *
 * @author: Fio
 * @version: 1.0
 */
public class Constant {
    public static String my_fio_userid = "fioclient";
    //public static String my_fio_userid = "user1";
    public static String[] listFriendName = {"User 1", "User 2", "User 3", "User 4", "User 5", "User 6", "fio clent"};
    public static String[] listFrienUserId = {"user1", "user2", "user3", "user4", "user5", "user6", "fioclient"};
    public static String appId = "2L3NRJ1BDF4O8P8FQB3Q7JSTRAHM23UJ";
    public static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkVnYxkfM5nwt71q/QC5OURLNk6gs/P/WqwSiHwBSq5XhLNuYR+3ahPnUSZ9ZEiRmjBrdRgyOMtsvTMyRtSAFhTWn5v0qgJWohUzk+GnpHDBSLC8g00AFXUo0USjkkRdQhtaTnO6IFdTXyHTAyACMv41CMSgVQgIyjvc/7csU3wel5HbaVxdM6iO7HCDwvsub+q1gRVuKLRxJ9KCn6xxdfHLEfcQtijOlwL+qhrbkLuvMW5T1+shF/of/Df4KFq4qVxFHy42YjRVGf8r/difa0d3sNbuFB7h8EGcc6yiqnoEco5k5e2zVQYoCYadwHDQWQQdUp1F44mwtSCXz7Rjr0QIDAQAB";
    public static String SecretCode = "P35CIRPLURF2TRPV";

}
